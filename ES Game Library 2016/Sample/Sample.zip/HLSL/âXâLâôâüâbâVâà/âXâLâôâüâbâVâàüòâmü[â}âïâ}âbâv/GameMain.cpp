#include "GameMain.h"

/// <summary>
/// Allows the game to perform any initialization it needs to before starting to run.
/// This is where it can query for any required services and load any non-graphic
/// related content.  Calling base.Initialize will enumerate through any components
/// and initialize them as well.
/// </summary>
void GameMain::Initialize()
{
	// TODO: Add your initialization logic here
	WindowTitle( TEXT("ES Game Library : �X�L�����b�V�����m�[�}���}�b�v�T���v��") );

	// �r���[�|�[�g���擾
	Viewport   view = GraphicsDevice.GetViewport();

	// �J�����ݒ�
	Camera->SetLookAt(Vector3(0.0f, -2.0f, -2.0f), Vector3(0.0f, 0.0f, 0.0f), Vector3_Up);
	Camera->SetPerspectiveFieldOfView(45.0f, (float)view.Width, (float)view.Height, 1.0f, 1000.0f);

	// �����_�����O�X�e�[�g�ݒ�
	GraphicsDevice.SetRenderState(NormalizeNormals, TRUE);
}

/// <summary>
/// LoadContent will be called once per game and is the place to load
/// all of your content.
/// </summary>
void GameMain::LoadContent()
{
	// TODO: use this.Content to load your game content here
	// ���f���ǂݍ���
	anime = GraphicsDevice.CreateAnimationModelFromX( TEXT("Bat/Bat.x"),
													  Compute_NormalTangent,
													  SkinningMethod_IndexedHLSL );
	anime->SetScale(0.75f);

	// �G�t�F�N�g�ǂݍ���
	bump  = GraphicsDevice.CreateEffectFromFile( TEXT("Bat/Bat.fx") );

	// �G�t�F�N�g�ݒ�|�O���[�o���ϐ��ݒ�
	bump ->SetFloat3("g_vLightDirection", Vector3_Up + Vector3_Forward);
	bump ->SetFloat ("g_fLightIntensity", 2.0f);

	// �G�t�F�N�g�ݒ�|�G�t�F�N�g�}�b�v�ǂݍ���
	bump ->SetEffectMap(TextureStage(0), TEXT("Bat/BatAlbedo.dds"   ) );
	bump ->SetEffectMap(TextureStage(1), TEXT("Bat/BatNormalMap.dds") );

	// �A�j���[�V�����p�O���[�o���ϐ����o�^
	anime->RegisterBoneMatricesByName(bump, "g_mWorldMatrixArray", "g_NumBones");
}

/// <summary>
/// UnloadContent will be called once per game and is the place to unload
/// all content.
/// </summary>
void GameMain::UnloadContent()
{
	// TODO: Unload any non ContentManager content here
}

/// <summary>
/// Allows the game to run logic such as updating the world,
/// checking for collisions, gathering input, and playing audio.
/// </summary>
/// <returns>
/// Scene continued value.
/// </returns>
int GameMain::Update()
{
    // TODO: Add your update logic here

	return 0;
}

/// <summary>
/// This is called when the game should draw itself.
/// </summary>
void GameMain::Draw()
{
	GraphicsDevice.Clear(Color_Black);

	// TODO: Add your drawing code here
	GraphicsDevice.BeginScene();

	bump ->SetFloat4x4("g_mViewProjection", Camera->GetViewProjectionMatrix());
	anime->Draw(bump, GameTimer.GetElapsedSecond());

	GraphicsDevice.EndScene();
}
