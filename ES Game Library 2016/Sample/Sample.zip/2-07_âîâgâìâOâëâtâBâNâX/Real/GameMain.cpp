#include "GameMain.h"

/// <summary>
/// Allows the game to perform any initialization it needs to before starting to run.
/// This is where it can query for any required services and load any non-graphic
/// related content.  Calling base.Initialize will enumerate through any components
/// and initialize them as well.
/// </summary>
void GameMain::Initialize()
{
	// TODO: Add your initialization logic here
	WindowTitle( TEXT("ES Game Library : ���g���Q�[���O���t�B�N�X") );

}

/// <summary>
/// LoadContent will be called once per game and is the place to load
/// all of your content.
/// </summary>
void GameMain::LoadContent()
{
	// TODO: use this.Content to load your game content here

}

/// <summary>
/// UnloadContent will be called once per game and is the place to unload
/// all content.
/// </summary>
void GameMain::UnloadContent()
{
	// TODO: Unload any non ContentManager content here
}

/// <summary>
/// Allows the game to run logic such as updating the world,
/// checking for collisions, gathering input, and playing audio.
/// </summary>
/// <returns>
/// Scene continued value.
/// </returns>
int GameMain::Update()
{
    // TODO: Add your update logic here


	return 0;
}

/// <summary>
/// This is called when the game should draw itself.
/// </summary>
void GameMain::Draw()
{

	GraphicsDevice.Clear(Color_White);

	Canvas canvas = GraphicsDevice.LockCanvas();

	Paint	paint;

	// ��
	paint .SetLineColor(Color_Black);
	paint .SetLineWidth(3);
	paint .SetPaintColor(Color(0, 182, 255));
	canvas.DrawArc(Rect(0, 0, 512, 512), 120.0f, 300.0f, false, paint);

	// ��2
	paint .SetPaintColor(Color_White);
	canvas.DrawCircle(256, 304, 192, paint);

	// ��
	canvas.DrawRoundRect(Rect(116, 53, 256, 223), 132, 132, paint);
	canvas.DrawRoundRect(Rect(256, 53, 396, 223), 132, 132, paint);

	// �ڋ�
	paint .SetPaintColor(Color_Black);
	canvas.DrawCircle(216, 180, 10, paint);
	canvas.DrawCircle(296, 180, 10, paint);

	// �@
	paint .SetPaintColor(Color_Red);
	canvas.DrawCircle(256, 223, 30, paint);

	// �@-��
	paint .SetLineWidth(0);
	paint .SetPaintColor(Color_White);
	canvas.DrawCircle(266, 210, 10, paint);

	// ��
	paint.SetLineWidth(3);
	canvas.DrawArc(Rect(110, 200, 400, 410), 10, 160, false, paint, PaintStyle_STROKE);

	// ���̂���Ȃ�����������
	paint .SetLineColor(Color_White);
	paint .SetLineWidth(10);
	canvas.DrawLine(110, 322, 400, 322, paint);

	// �@�̉�
	paint .SetLineColor(Color_Black);
	paint .SetLineWidth(3);
	canvas.DrawLine(256, 252, 256, 408, paint);

	// �Ђ�
	canvas.DrawLine( 95, 230, 195, 260, paint);
	canvas.DrawLine( 95, 270, 195, 270, paint);
	canvas.DrawLine( 95, 310, 195, 280, paint);
	canvas.DrawLine(415, 230, 315, 260, paint);
	canvas.DrawLine(415, 270, 315, 270, paint);
	canvas.DrawLine(415, 310, 315, 280, paint);

	// ���
	paint .SetPaintColor(Color_Brown);
	canvas.DrawRoundRect(Rect(96, 464, 416, 498), 20, 20, paint);

	// ��
	paint .SetPaintColor(Color_Yellow);
	canvas.DrawCircle(256, 498, 30, paint);

	// ��-��������
	paint .SetLineWidth(2);
	canvas.DrawLine(230, 484, 280, 484, paint);
	canvas.DrawLine(230, 490, 282, 490, paint);

	paint .SetLineWidth(4);
	canvas.DrawLine(256, 508, 256, 525, paint);

	paint .SetPaintColor(Color_Black);
	canvas.DrawCircle(256, 500, 8, paint);

	GraphicsDevice.UnlockCanvas();
}
