#include "GameMain.h"

/// <summary>
/// Allows the game to perform any initialization it needs to before starting to run.
/// This is where it can query for any required services and load any non-graphic
/// related content.  Calling base.Initialize will enumerate through any components
/// and initialize them as well.
/// </summary>
void GameMain::Initialize()
{
	// TODO: Add your initialization logic here
	WindowTitle( TEXT("ES Game Library : �A���t�@�u�����h�T���v��") );

	// �r���[�|�[�g���擾
	Viewport   view = GraphicsDevice.GetViewport();

	// �J�����ݒ�
	Camera->SetLookAt(Vector3(0.0f, 5.0f, -10.0f), Vector3(0.0f, 0.0f, 0.0f), Vector3_Up);
	Camera->SetPerspectiveFieldOfView(45.0f, (float)view.Width, (float)view.Height, 1.0f, 1000.0f);

	// ���C�g�ݒ�
	Light   light;
	light.Type      = Light_Directional;
	light.Diffuse   = Color(1.0f, 0.5f, 0.3f);
	light.Ambient   = Color(1.0f, 0.5f, 0.3f);
	light.Specular  = Color(1.0f, 0.5f, 0.3f);
	light.Direction = Vector3_Down + Vector3_Backward;
	GraphicsDevice.SetLight(light);

	// �����_�����O�X�e�[�g�ݒ�
	GraphicsDevice.SetRenderState(CullMode, CullMode_None);
	GraphicsDevice.SetRenderState(NormalizeNormals,  TRUE);

	// �ϐ�������
	pos   = Vector3(0.0f, 0.0f, -1.5f);
	run   = false;
	front = true;
}

/// <summary>
/// LoadContent will be called once per game and is the place to load
/// all of your content.
/// </summary>
void GameMain::LoadContent()
{
	// TODO: use this.Content to load your game content here
	// ���f������
	SimpleShape   shape;
	shape.Type = Shape_Teapot;
	model = GraphicsDevice.CreateModelFromSimpleShape(shape);
	model->SetPosition(0.0f, 2.0f, 0.0f);

	// �}�e���A���ݒ�
	Material   mtrl;
	mtrl.Diffuse  = Color(0.5f, 0.5f, 0.5f, 0.5f);
	mtrl.Ambient  = Color(0.2f, 0.2f, 0.2f, 0.5f);
	mtrl.Specular = Color(0.3f, 0.3f, 0.3f, 0.5f);
	mtrl.Emissive = Color(0.0f, 0.0f, 0.0f);
	mtrl.Power    = 1.0f;
	model->SetMaterial(mtrl);

	// �A�j���[�V�������f���ǂݍ���
	anime = GraphicsDevice.CreateAnimationModelFromX( TEXT("Mikoto/Mikoto.x") );
	anime->ChangeTexture("kao.jpeg", "Mikoto/���.jpeg");
	anime->SetScale(0.015f);
}

/// <summary>
/// UnloadContent will be called once per game and is the place to unload
/// all content.
/// </summary>
void GameMain::UnloadContent()
{
	// TODO: Unload any non ContentManager content here
}

/// <summary>
/// Allows the game to run logic such as updating the world,
/// checking for collisions, gathering input, and playing audio.
/// </summary>
/// <returns>
/// Scene continued value.
/// </returns>
int GameMain::Update()
{
    // TODO: Add your update logic here
	run = false;

	// �L�����N�^�[�ړ�
	KeyboardState   key = Keyboard->GetState();
	if(key.IsKeyDown(Keys_Up  )) {
		pos.z += 0.075f;
		run    = true;
		front  = false;
	}
	if(key.IsKeyDown(Keys_Down)) {
		pos.z -= 0.075f;
		run    = true;
		front  = true;
	}

	return 0;
}

/// <summary>
/// This is called when the game should draw itself.
/// </summary>
void GameMain::Draw()
{
	GraphicsDevice.Clear(Color_Tomato);

	// TODO: Add your drawing code here
	GraphicsDevice.BeginScene();

	// ���f���ݒ�
	// �p��
	if(run) {
		anime->SetTrackEnable(0, FALSE);
		anime->SetTrackEnable(4, TRUE );
	} else {
		anime->SetTrackEnable(0, TRUE );
		anime->SetTrackEnable(4, FALSE);
	}

	// ����
	if(front)
		anime->SetRotation(0.0f, 0.0f, 0.0f);
	else
		anime->SetRotation(0.0f, 180.0f, 0.0f);

	// �ʒu
	anime->SetPosition(pos);


	// �e�`��
	GraphicsDevice.BeginShadowRendering();

	Matrix   mat;

	// �A�j���[�V�������f��
	mat = Matrix_CreateShadow(Light_Point, Vector3(0.0f, 10.0f, 15.0f),
							  anime->GetPosition(), Vector3(0.0f, 0.0f, 0.0f), Vector3_Up);
	anime->DrawShadow(mat, 0.75f);

	// �e�B�[�|�b�g
	mat = Matrix_CreateShadow(Light_Directional, Vector3_Down,
							  model->GetPosition(),
							  Vector3(0.0f, -(model->GetPosition().y + 0.9f), 0.0f), Vector3_Up);
	model->DrawShadow(mat, 0.6f);

	GraphicsDevice.EndShadowRendering();


	// �������`��
	GraphicsDevice.BeginAlphaBlend();

	if(pos.z <= model->GetPosition().z - 1.1f) {
		model->DrawAlpha(0.5f);
		anime->DrawAlpha(GameTimer.GetElapsedSecond(), 0.75f);
	} else {
		anime->DrawAlpha(GameTimer.GetElapsedSecond(), 0.75f);
		model->DrawAlpha(0.5f);
	}

	GraphicsDevice.EndAlphaBlend();

	GraphicsDevice.EndScene();
}
