#pragma once

#include "XNA.h"

class GameMain : public CGameScene {
protected:
	spriteBatch   SpriteBatch;
	FONT          DefaultFont;

public:
	GameMain() : SpriteBatch(), DefaultFont(GraphicsDevice.CreateDefaultFont())
	{
		ContentRootDirectory( TEXT("Content") );

		Initialize(); 
		LoadContent();
	}

	virtual ~GameMain()
	{ 
		UnloadContent();

		SoundDevice.ReleaseAllMusics();
		SoundDevice.ReleaseAllSounds();

		GraphicsDevice.ReleaseAllRenderTargets();
		GraphicsDevice.ReleaseAllStateBlocks();
		GraphicsDevice.ReleaseAllFonts();
		GraphicsDevice.ReleaseAllSprites();
		GraphicsDevice.ReleaseAllAnimationModels();
		GraphicsDevice.ReleaseAllModels();
		GraphicsDevice.ReleaseAllVertexBuffers();
		GraphicsDevice.ReleaseAllEffects();
	}

	virtual void Initialize();
	virtual void LoadContent();

	virtual void UnloadContent();

	virtual int  Update();
	virtual void Draw();

private:
	// �ϐ��錾
	// �v���C���[���W
	Vector3       PlyPos;
	int           px, py;

	// �N���A�t���O
	bool          clear;

	// �X�v���C�g
	ISprite*      PlySprite;
	ISprite*      WallSprite;
	ISprite*      GoalSprite;
	ISprite*      FieldSprite;
	ISprite*      ItemSprite;

	// �n�`�f�[�^
	tstring       MapData [10];

	// �ړ��p�f�[�^
	tstring       MoveData[10];
/*
	tstring       MapData0;
	tstring       MapData1;
	tstring       MapData2;
	tstring       MapData3;
	tstring       MapData4;
	tstring       MapData5;
	tstring       MapData6;
	tstring       MapData7;
	tstring       MapData8;
	tstring       MapData9;
*/
	// �֐��v���g�^�C�v
};