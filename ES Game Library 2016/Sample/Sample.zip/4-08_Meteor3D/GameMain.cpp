#include "GameMain.h"

/// <summary>
/// Allows the game to perform any initialization it needs to before starting to run.
/// This is where it can query for any required services and load any non-graphic
/// related content.  Calling base.Initialize will enumerate through any components
/// and initialize them as well.
/// </summary>
void GameMain::Initialize()
{
	// TODO: Add your initialization logic here
	WindowTitle( TEXT("ES Game Library : Meteor3D") );

	// �r���[�|�[�g���擾
	Viewport   view = GraphicsDevice.GetViewport();

	// �J�����ݒ�
	Camera->SetLookAt(Vector3(0.0f, 0.3f, -0.5f), Vector3(0.0f, 0.3f, 5.0f), Vector3_Up);
	Camera->SetPerspectiveFieldOfView(45.0f, (float)view.Width, (float)view.Height, 1.0f, 500.0f);

	// ���C�g�ݒ�
	Light   light;
	light.Type      = Light_Directional;			// �f�B���N�V���i�����C�g
	light.Diffuse   = Color(1.0f, 1.0f, 1.0f);		// �f�B�t���[�Y�F
	light.Ambient   = Color(1.0f, 1.0f, 1.0f);		// �A���r�G���g�F
	light.Specular  = Color(1.0f, 1.0f, 1.0f);		// �X�y�L�����[�F
	light.Direction = Vector3_Down;					// ���C�g�̕���
	GraphicsDevice.SetLight(light);

	// �ϐ�������
	m_Score = 0;
	m_Hit   = 0;

	// �v���C���[
	m_PlyPos = Vector3(0.0f,   0.0f, 0.0f);
	m_PlyRot = Vector3(0.0f, -90.0f, 0.0f);

	// 覐�
	for(int i = 0; i < METEO_MAX; i++)
		InitMeteo(i);
}

/// <summary>
/// LoadContent will be called once per game and is the place to load
/// all of your content.
/// </summary>
void GameMain::LoadContent()
{
	// TODO: use this.Content to load your game content here
	SimpleShape   shape;
	Material      mat;

	// �e�B�[�|�b�g����
	shape.Type   = Shape_Teapot;
	m_pPlyModel  = GraphicsDevice.CreateModelFromSimpleShape(shape);

	// �}�e���A���ݒ�
	mat.Diffuse  = Color(0.5f, 0.5f, 0.5f);
	mat.Ambient  = Color(0.2f, 0.2f, 0.2f);
	mat.Specular = Color(0.3f, 0.3f, 0.3f);
	mat.Emissive = Color(0.0f, 0.0f, 0.0f);
	mat.Power    = 1.0f;
	m_pPlyModel->SetMaterial(mat);

	// ������
	shape.Type    = Shape_Sphere;
	shape.Radius  = 1.0f;
	shape.Slices  = 8;
	shape.Stacks  = 3;
	m_pMeteoModel = GraphicsDevice.CreateModelFromSimpleShape(shape);

	// �}�e���A���ݒ�
	mat.Diffuse   = Color(0.4f, 0.4f, 0.4f);
	mat.Ambient   = Color(0.2f, 0.2f, 0.2f);
	mat.Specular  = Color(1.0f, 1.0f, 1.0f);
	mat.Emissive  = Color(0.0f, 0.0f, 0.0f);
	mat.Power     = 1.0f;
	m_pMeteoModel->SetMaterial(mat);

	// �w�i�ǂݍ���
	m_pBGSprite = GraphicsDevice.CreateSpriteFromFile( TEXT("BG.jpg") );
}

/// <summary>
/// UnloadContent will be called once per game and is the place to unload
/// all content.
/// </summary>
void GameMain::UnloadContent()
{
	// TODO: Unload any non ContentManager content here
}

/// <summary>
/// Allows the game to run logic such as updating the world,
/// checking for collisions, gathering input, and playing audio.
/// </summary>
/// <returns>
/// Scene continued value.
/// </returns>
int GameMain::Update()
{
    // TODO: Add your update logic here
	m_Score++;

	// �v���C���[����
	Vector3   dist = m_PlyPos;	// �J�����ړ��p

	m_PlyRot.x = 0.0f;
	m_PlyRot.z = 0.0f;
	KeyboardState   Key = Keyboard->GetState();
	if(Key.IsKeyDown(Keys_Left )) {
        m_PlyPos.x -=  1.5f;
		m_PlyRot.x += 30.0f;
	}
	if(Key.IsKeyDown(Keys_Right)) {
        m_PlyPos.x +=  1.5f;
		m_PlyRot.x -= 30.0f;
	}

	if(Key.IsKeyDown(Keys_Up  )) {
        m_PlyPos.y +=  1.5f;
		m_PlyRot.z += 10.0f;
	}
	if(Key.IsKeyDown(Keys_Down)) {
        m_PlyPos.y -=  1.5f;
		m_PlyRot.z -= 10.0f;
	}

	// �J�����ړ�
	dist = (m_PlyPos - dist);
	Camera->Move(dist);
	Camera->Update();

    // 覐Έړ�
    for(int i = 0; i < METEO_MAX; i++) {
        m_MeteoPos[i].z -= m_MeteoSpd[i];
        if(m_MeteoPos[i].z < -2.0f) {
			InitMeteo(i);
		}
    }

    // �Փˌ��o
    const float plyR = 0.4f;	// ���a
    for(int i = 0; i < METEO_MAX; i++) {
        if(Vector3_Distance(m_PlyPos, m_MeteoPos[i]) < plyR + m_MeteoSize[i])
            m_Hit = 30;
    }

	return 0;
}

/// <summary>
/// This is called when the game should draw itself.
/// </summary>
void GameMain::Draw()
{
	GraphicsDevice.Clear(Color_Black);

	// TODO: Add your drawing code here
	GraphicsDevice.BeginScene();

	// 2D�`��
	SpriteBatch.Begin();

	// �w�i
	SpriteBatch.Draw(m_pBGSprite, Vector3(0.0f, 0.0f, 1.0f), 0.25f);

	// �X�R�A
	SpriteBatch.DrawString(DefaultFont, Vector2(0.0f, 0.0f), Color_White, TEXT("SCORE %d"), m_Score);

	// �_���[�W
	if(m_Hit > 0) {
		SpriteBatch.DrawString(DefaultFont, TEXT("DAMAGE"), Vector2(600.0f, 310.3f), Color_Red);
		m_Hit--;
	}

	SpriteBatch.End();


	// 3D�`��
	// �v���C���[
	GraphicsDevice.SetRenderState(CullMode, CullMode_None);
	m_pPlyModel->SetScale(0.4f, 0.4f, 0.4f);
	m_pPlyModel->SetRotation(m_PlyRot);
	m_pPlyModel->SetPosition(m_PlyPos);
	m_pPlyModel->Draw();

	// 覐�
	GraphicsDevice.SetRenderState(CullMode, CullMode_CullClockwiseFace);
	for(int i = 0; i < METEO_MAX; i++) {
		m_pMeteoModel->SetPosition(m_MeteoPos[i]);
		m_pMeteoModel->SetScale(m_MeteoSize[i], m_MeteoSize[i], m_MeteoSize[i]);
		m_pMeteoModel->Draw();
	}

	GraphicsDevice.EndScene();
}

//------------------------------------------------------------------------------
//	�w�肳�ꂽ�Y����覐΂�����������
//------------------------------------------------------------------------------
void GameMain::InitMeteo(int idx)
{
	m_MeteoPos [idx].x = m_PlyPos.x + m_Random.Next(-200, 200) + m_Random.NextFloat();
	m_MeteoPos [idx].y = m_PlyPos.y + m_Random.Next(-150, 150) + m_Random.NextFloat();
	m_MeteoPos [idx].z = m_PlyPos.z + m_Random.Next( 500, 700) + m_Random.NextFloat();
	m_MeteoSize[idx]   = m_Random.Next(  10000,  300000) / 100000.0f;
	m_MeteoSpd [idx]   = m_Random.Next(1000000, 4000000) / 100000.0f;
}
