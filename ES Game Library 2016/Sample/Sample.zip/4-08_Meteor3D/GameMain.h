#pragma once

#include "XNA.h"

class GameMain : public CGameScene {
protected:
	spriteBatch   SpriteBatch;
	FONT          DefaultFont;

public:
	GameMain() : SpriteBatch(), DefaultFont(GraphicsDevice.CreateDefaultFont())
	{
		ContentRootDirectory( TEXT("Content") );

		Initialize(); 
		LoadContent();
	}

	virtual ~GameMain()
	{ 
		UnloadContent();

		SoundDevice.ReleaseAllMusics();
		SoundDevice.ReleaseAllSounds();

		GraphicsDevice.ReleaseAllRenderTargets();
		GraphicsDevice.ReleaseAllStateBlocks();
		GraphicsDevice.ReleaseAllFonts();
		GraphicsDevice.ReleaseAllSprites();
		GraphicsDevice.ReleaseAllAnimationModels();
		GraphicsDevice.ReleaseAllModels();
		GraphicsDevice.ReleaseAllVertexBuffers();
		GraphicsDevice.ReleaseAllEffects();
	}

protected:
	virtual void Initialize();
	virtual void LoadContent();

	virtual void UnloadContent();

	virtual int  Update();
	virtual void Draw();

private:
	// �ϐ��錾
	Random     m_Random;
	int        m_Score;
	int        m_Hit;

	// �v���C���[
	IModel*    m_pPlyModel;
	Vector3    m_PlyPos;
	Vector3    m_PlyRot;

	// 覐�
	enum { METEO_MAX = 1000 };
	IModel*    m_pMeteoModel;
	Vector3    m_MeteoPos [METEO_MAX];
	float      m_MeteoSize[METEO_MAX];
	float      m_MeteoSpd [METEO_MAX];

	// �X�v���C�g
	ISprite*   m_pBGSprite;

	// �֐��v���g�^�C�v
	void InitMeteo(int idx);
};