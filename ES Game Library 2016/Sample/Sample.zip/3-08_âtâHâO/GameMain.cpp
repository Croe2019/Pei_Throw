#include "GameMain.h"

/// <summary>
/// Allows the game to perform any initialization it needs to before starting to run.
/// This is where it can query for any required services and load any non-graphic
/// related content.  Calling base.Initialize will enumerate through any components
/// and initialize them as well.
/// </summary>
void GameMain::Initialize()
{
	// TODO: Add your initialization logic here
	WindowTitle( TEXT("ES Game Library : �t�H�O(�Œ�@�\)�T���v��") );

	// �r���[�|�[�g���擾
	Viewport   view = GraphicsDevice.GetViewport();

	// �J�����ݒ�
	Camera->SetLookAt(Vector3(0.0f, 0.0f, -2.0f), Vector3(0.0f, 0.0f, 0.0f), Vector3_Up);
	Camera->SetPerspectiveFieldOfView(45.0f, (float)view.Width, (float)view.Height, 1.0f, 1000.0f);

	// ���C�g�ݒ�
	Light   light;
	light.Type      = Light_Directional;
	light.Diffuse   = Color(Color_White);
	light.Ambient   = Color(Color_White);
	light.Specular  = Color(Color_White);
	light.Direction = Vector3_Down + Vector3_Forward;
	GraphicsDevice.SetLight(light);

	// �����_�[�X�e�[�g
	GraphicsDevice.SetRenderState(CullMode, CullMode_None);
	GraphicsDevice.SetRenderState(NormalizeNormals,  TRUE);

	// �t�H�O�ݒ�
	GraphicsDevice.SetRenderState(FogEnable, TRUE);
	GraphicsDevice.SetRenderState(FogVertexMode, FogMode_Linear);
	GraphicsDevice.SetRenderState(FogColor, Color_CornflowerBlue);
	GraphicsDevice.SetFloatRenderState(FogStart, 5.0f);
	GraphicsDevice.SetFloatRenderState(FogEnd,  20.0f);

	// �ϐ�������
	pos   = Vector3_Zero;
	run   = false;
	front = true;
}

/// <summary>
/// LoadContent will be called once per game and is the place to load
/// all of your content.
/// </summary>
void GameMain::LoadContent()
{
	// TODO: use this.Content to load your game content here
	// ���f���ǂݍ���
	anime = GraphicsDevice.CreateAnimationModelFromX( TEXT("Mikoto/Mikoto.x") );
	anime->SetScale(0.005f);
}

/// <summary>
/// UnloadContent will be called once per game and is the place to unload
/// all content.
/// </summary>
void GameMain::UnloadContent()
{
	// TODO: Unload any non ContentManager content here
}

/// <summary>
/// Allows the game to run logic such as updating the world,
/// checking for collisions, gathering input, and playing audio.
/// </summary>
/// <returns>
/// Scene continued value.
/// </returns>
int GameMain::Update()
{
    // TODO: Add your update logic here
	run = false;

	// �L�����N�^�[�ړ�
	KeyboardState   key = Keyboard->GetState();
	if(key.IsKeyDown(Keys_Up  )) {
		pos.z += 0.075f;
		run    = true;
		front  = false;
	}
	if(key.IsKeyDown(Keys_Down)) {
		pos.z -= 0.075f;
		run    = true;
		front  = true;
	}

	return 0;
}

/// <summary>
/// This is called when the game should draw itself.
/// </summary>
void GameMain::Draw()
{
	GraphicsDevice.Clear(Color_CornflowerBlue);

	// TODO: Add your drawing code here
	GraphicsDevice.BeginScene();

	// �A�j���[�V�����p�^�[���ݒ�
	if(run) {
		anime->SetTrackEnable(0, FALSE);
		anime->SetTrackEnable(4, TRUE );
	} else {
		anime->SetTrackEnable(0, TRUE );
		anime->SetTrackEnable(4, FALSE);
	}

	// �����ݒ�
	if(front)
		anime->SetRotation(0.0f, 0.0f, 0.0f);
	else
		anime->SetRotation(0.0f, 180.0f, 0.0f);

	// ���f���`��
	anime->SetPosition(pos);
	anime->Draw(GameTimer.GetElapsedSecond());

	// ���W�\��
	SpriteBatch.Begin();
	SpriteBatch.DrawString(DefaultFont, Vector2_Zero, Color_White, TEXT("�ʒu:%.3f"), pos.z);
	SpriteBatch.End();

	GraphicsDevice.EndScene();
}
