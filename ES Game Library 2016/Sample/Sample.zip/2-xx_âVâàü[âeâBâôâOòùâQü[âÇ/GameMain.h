#pragma once

#include "XNA.h"

class GameMain : public CGameScene {
protected:
	spriteBatch   SpriteBatch;
	FONT          DefaultFont;

public:
	GameMain() : SpriteBatch(), DefaultFont(GraphicsDevice.CreateDefaultFont())
	{
		ContentRootDirectory( TEXT("Content") );

		Initialize(); 
		LoadContent();
	}

	virtual ~GameMain()
	{ 
		UnloadContent();

		SoundDevice.ReleaseAllMusics();
		SoundDevice.ReleaseAllSounds();

		GraphicsDevice.ReleaseAllRenderTargets();
		GraphicsDevice.ReleaseAllStateBlocks();
		GraphicsDevice.ReleaseAllFonts();
		GraphicsDevice.ReleaseAllSprites();
		GraphicsDevice.ReleaseAllAnimationModels();
		GraphicsDevice.ReleaseAllModels();
		GraphicsDevice.ReleaseAllVertexBuffers();
		GraphicsDevice.ReleaseAllEffects();
	}

protected:
	virtual void Initialize();
	virtual void LoadContent();

	virtual void UnloadContent();

	virtual int  Update();
	virtual void Draw();

private:
	// �ϐ��錾
	// ����
	Random    Rand;

	int       Score;	// �X�R�A
	int       GameMode;	// �Q�[�����[�h

	// �w�i
	SPRITE    BGSpr;

	// �v���C���[
	SPRITE    PlySpr;
	float     PlyX, PlyY;
	int       PlyHP;

	// �v���C���[�V���b�g
	SPRITE    PstSpr;
	bool      PstShot;
	float     PstX, PstY;

	// �G
	SPRITE    EnmSpr;
	float     EnmX, EnmY;
	int       EnmHP;

	// �G�����f�[�^
	tstring   EnmMoveData;
	UINT      EnmMoveCount;

	// �G�V���b�g
	SPRITE    EstSpr;
	bool      EstShot;
	float     EstX, EstY;

	// �����܂�
	SPRITE   OsiSpr;

	// �֐��v���g�^�C�v
	bool IsIntersect(float ax1, float ay1, float ax2, float ay2,
					 float bx1, float by1, float bx2, float by2);
};