#include "GameMain.h"

/// <summary>
/// Allows the game to perform any initialization it needs to before starting to run.
/// This is where it can query for any required services and load any non-graphic
/// related content.  Calling base.Initialize will enumerate through any components
/// and initialize them as well.
/// </summary>
void GameMain::Initialize()
{
	// TODO: Add your initialization logic here
	WindowTitle( TEXT("ES Game Library : �e�N�X�`���T���v��") );

	// �r���[�|�[�g���擾
	Viewport   view = GraphicsDevice.GetViewport();

	// �J�����ݒ�
	Camera->SetLookAt(Vector3(0.0f, 0.0f, -10.0f), Vector3(0.0f, 0.0f, 0.0f), Vector3_Up);
	Camera->SetPerspectiveFieldOfView(45.0f, (float)view.Width, (float)view.Height, 1.0f, 1000.0f);

	// �ϐ�������
	tex_ptn = 0;
}

/// <summary>
/// LoadContent will be called once per game and is the place to load
/// all of your content.
/// </summary>
void GameMain::LoadContent()
{
	// TODO: use this.Content to load your game content here
	// �e�N�X�`���ǂݍ���
	texture = GraphicsDevice.CreateSpriteFromFile( TEXT("chara128.bmp") );
}

/// <summary>
/// UnloadContent will be called once per game and is the place to unload
/// all content.
/// </summary>
void GameMain::UnloadContent()
{
	// TODO: Unload any non ContentManager content here
}

/// <summary>
/// Allows the game to run logic such as updating the world,
/// checking for collisions, gathering input, and playing audio.
/// </summary>
/// <returns>
/// Scene continued value.
/// </returns>
int GameMain::Update()
{
    // TODO: Add your update logic here
	tex_ptn = (tex_ptn + 1) % 5;

	return 0;
}

/// <summary>
/// This is called when the game should draw itself.
/// </summary>
void GameMain::Draw()
{
	GraphicsDevice.Clear(Color_CornflowerBlue);

	// TODO: Add your drawing code here
	GraphicsDevice.BeginScene();

	// ���_�ݒ�
	VertexPositionColorTexture   v[6];

	// ���_�O
	v[0].x     = -1.0f;
	v[0].y     =  1.0f;
	v[0].color = Color_Cyan;
	v[0].tu    = tex_ptn * 0.125f;
	v[0].tv    = 0.0f;

	// ���_�P
	v[1].x     =  1.0f;
	v[1].y     = -1.0f;
	v[1].color = Color_Magenta;
	v[1].tu    = tex_ptn * 0.125f + 0.125f;
	v[1].tv    = 1.0f;

	// ���_�Q
	v[2].x     = -1.0f;
	v[2].y     = -1.0f;
	v[2].color = Color_Yellow;
	v[2].tu    = v[0].tu;
	v[2].tv    = 1.0f;

	// ���_�R
	v[3]       = v[0];

	// ���_�S
	v[4].x     = 1.0f;
	v[4].y     = 1.0f;
	v[4].color = Color_White;
	v[4].tu    = v[1].tu;
	v[4].tv    = 0.0f;

	// ���_�T
	v[5]       = v[1];

	// ���C�e�B���O�ςݒ��_�́A�K��Direct3D�ɂ��Ɩ����Z�𖳌��ɂ���
	GraphicsDevice.SetRenderState(LightEnable, FALSE);

	// ���[���h�ϊ��s��ݒ�
	GraphicsDevice.SetWorldMatrix(Matrix_Identity());

	// �e�N�X�`���ݒ�
	GraphicsDevice.SetTexture(0, texture->GetTexture());

	// �v���~�e�B�u�`��
	GraphicsDevice.DrawUserPrimitives(PrimitiveType_TriangleList, v, 2, v[0].FVF());

	// �Ɩ����Z��߂�
	GraphicsDevice.SetRenderState(LightEnable, TRUE);

	GraphicsDevice.EndScene();
}
