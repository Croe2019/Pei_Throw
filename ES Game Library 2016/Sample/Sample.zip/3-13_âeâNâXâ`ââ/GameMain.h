#pragma once

#include "XNA.h"

class GameMain : public CGameScene {
protected:
	spriteBatch   SpriteBatch;
	FONT          DefaultFont;

public:
	GameMain() : SpriteBatch(), DefaultFont(GraphicsDevice.CreateDefaultFont())
	{
		ContentRootDirectory( TEXT("Content") );

		Initialize(); 
		LoadContent();
	}

	virtual ~GameMain()
	{ 
		UnloadContent();

		SoundDevice.ReleaseAllMusics();
		SoundDevice.ReleaseAllSounds();

		GraphicsDevice.ReleaseAllRenderTargets();
		GraphicsDevice.ReleaseAllStateBlocks();
		GraphicsDevice.ReleaseAllFonts();
		GraphicsDevice.ReleaseAllSprites();
		GraphicsDevice.ReleaseAllAnimationModels();
		GraphicsDevice.ReleaseAllModels();
		GraphicsDevice.ReleaseAllVertexBuffers();
		GraphicsDevice.ReleaseAllEffects();
	}

protected:
	virtual void Initialize();
	virtual void LoadContent();

	virtual void UnloadContent();

	virtual int  Update();
	virtual void Draw();

private:
	// �ϐ��錾
	SPRITE   texture;

	// �֐��v���g�^�C�v

};